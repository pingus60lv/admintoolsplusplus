package me.pingus.atpp;

import java.util.logging.Logger;

import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import me.pingus.atpp.commands.commandAtabout;
import me.pingus.atpp.commands.commandAtfeed;
import me.pingus.atpp.commands.commandAtheal;
import me.pingus.atpp.commands.commandAtlaunch;

public class AdminToolsPlusPlus extends JavaPlugin{
	public final Logger logger = Logger.getLogger("Minecraft");
	 
	public static AdminToolsPlusPlus plugin;
	
	public void onEnable(){
		PluginDescriptionFile pdfFile = this.getDescription();
		// gets the commands from diffrent classes
		getCommand("atabout").setExecutor(new commandAtabout());
		getCommand("atheal").setExecutor(new commandAtheal());
		getCommand("atfeed").setExecutor(new commandAtfeed());
		getCommand("atlaunch").setExecutor(new commandAtlaunch());
		// start message
		this.logger.info(pdfFile.getName()+" "+pdfFile.getVersion()+ " has been enabled!");
		PluginManager pm = getServer().getPluginManager();
	}
	
	public void onDisable(){
		PluginDescriptionFile pdfFile = this.getDescription();
		// onDisable message
		this.logger.info(pdfFile.getName()+ " has been disabled!");
	}
}
