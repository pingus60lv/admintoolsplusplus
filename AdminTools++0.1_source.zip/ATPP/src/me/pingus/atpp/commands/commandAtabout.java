package me.pingus.atpp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;
// atabout tells info about the plugin
public class commandAtabout implements CommandExecutor{
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args){
		Player player = (Player) sender;
		if(commandLabel.equalsIgnoreCase("atabout")){
			player.sendMessage(ChatColor.GRAY + "[AdminTools 0.1] Made by Pingus");
		}
		
		return false;
	}
}
