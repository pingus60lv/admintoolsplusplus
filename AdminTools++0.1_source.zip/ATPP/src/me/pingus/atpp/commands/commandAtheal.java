package me.pingus.atpp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;

public class commandAtheal implements CommandExecutor{

	// atheal heals a player
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args){
		if(!(sender instanceof Player)){
			sender.sendMessage("Only players can run this command!");
		}
		Player player = (Player) sender;
		if(commandLabel.equalsIgnoreCase("atheal")&& args.length == 0){
			player.setHealth(player.getMaxHealth());
			// Also removes burning e.t.c
			player.setFireTicks(0);
			player.sendMessage(ChatColor.GRAY + "You've healed yourself!");
		}else if(args.length == 1 && sender instanceof Player){
			if(player.getServer().getPlayer(args[0])!=null){
				Player target = player.getServer().getPlayer(args[0]);
				target.setHealth(target.getMaxHealth());
				target.setFireTicks(0);
				player.sendMessage(ChatColor.GRAY + "You've healed "+ChatColor.LIGHT_PURPLE+ target.getName()+"!");
				target.sendMessage(ChatColor.GRAY+"You have been healed by "+ChatColor.LIGHT_PURPLE+player.getName()+"!");
			}else{
				player.sendMessage(ChatColor.RED + "This player isn't online!");
			}
			
			}
		return false;
	}

}
