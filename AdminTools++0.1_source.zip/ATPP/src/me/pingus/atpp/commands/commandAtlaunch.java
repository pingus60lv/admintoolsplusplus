package me.pingus.atpp.commands;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;

public class commandAtlaunch implements CommandExecutor{
	//atlaunch launches player in the sky (500 blocks) (pretty times).
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("You must be a player to call this command!");
		}
		Player player = (Player) sender;
		if(commandLabel.equalsIgnoreCase("atlaunch")&& args.length == 0){
			player.sendMessage(ChatColor.RED + "You need to specify what player will be launched! example: /atlaunch player");
		}else if(args.length == 1){
			Player target = player.getServer().getPlayer(args[0]);
			Location tloc = target.getLocation();
			tloc.setY(500);
			player.teleport(tloc);
			player.sendMessage(ChatColor.GRAY + "You've launched "+ChatColor.LIGHT_PURPLE+target.getName()+"!");
			target.sendMessage(ChatColor.GRAY + "You have been launched in the sky!");
		}else{
			
		}
		
		return false;
	}

}
