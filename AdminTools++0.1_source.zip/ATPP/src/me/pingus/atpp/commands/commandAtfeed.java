package me.pingus.atpp.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import net.md_5.bungee.api.ChatColor;

public class commandAtfeed implements CommandExecutor{
	@Override
	// atfeed feeds a player
	public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args){
		if(!(sender instanceof Player)){
			sender.sendMessage("Only players can run this command!");
		}
		Player player = (Player) sender;
		if(commandLabel.equalsIgnoreCase("atfeed")&& args.length == 0){
			player.setFoodLevel(player.getFoodLevel() * 20);
			player.sendMessage(ChatColor.GRAY + "You have fed yourself!");
		}else if(args.length==1 && sender instanceof Player){
			if(player.getServer().getPlayer(args[0])!=null){
				Player target = player.getServer().getPlayer(args[0]);
				target.setFoodLevel(20);
				player.sendMessage(ChatColor.GRAY + "You've fed "+ ChatColor.LIGHT_PURPLE + target.getName()+"!");
				target.sendMessage(ChatColor.GRAY + "You have been fed by " +ChatColor.LIGHT_PURPLE+player.getName()+"!" );
			}else{
				player.sendMessage(ChatColor.RED + "This player isn't online!");
			}
		}
		return false;
	}
}
